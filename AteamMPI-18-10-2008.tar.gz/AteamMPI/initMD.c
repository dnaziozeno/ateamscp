/* ------------------------------------------------------------------------- */
/*                                                                           */
/* DISSERTACAO DE MESTRADO -> DCC-UNICAMP                                    */
/*                                                                           */
/* Titulo    : Resolucao de problemas de Recobrimento  e  Particionamento de */
/*             Conjuntos com o uso de Times Assincronos.                     */
/*                                                                           */
/* Orientador: Marcus Vinicius S. Poggi de Aragao                            */
/* Orientando: Humberto Jose Longo                                           */
/*                                                                           */
/* Alteracoes: 0 -> (10/09/94)                                               */
/*                                                                           */
/* ------------------------------------------------------------------------- */

/* ------------------------------------------------------------------------- */
/* Este arquivo contem o codigo necessario para o agente InitMD. Este agente */
/* inicia a memoria de solucoes duais com solucoes geradas geradas  por  uma */
/* heuristica gulosa.                                                        */
/* ------------------------------------------------------------------------- */
 
/* ------------------------------------------------------------------------- */
/* /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/ */
/* ------------------------------------------------------------------------- */

#include "globais.h"
#include "agentes.h"

int    *I_u     = NULL,
       *inact   = NULL;
double *delta_u = NULL;

void ExecAgInitMD(MPI_Comm comm);
MPI_Comm InitMD(int argc,char *argv[]);

/* ------------------------------------------------------------------------- */
/* /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/ */
/* ------------------------------------------------------------------------- */

int main(int argc,char *argv[])
{
  int numSpawns = 1, errcodes[numSpawns], size, rank;
/*
    int argcInitMD = 4;
    char *argvInitMD[4];

    argvInitMD[0] = (char *) malloc (512 * sizeof(char));
    argvInitMD[1] = (char *) malloc (512 * sizeof(char));
    argvInitMD[2] = (char *) malloc (512 * sizeof(char));
    argvInitMD[3] = (char *) malloc (512 * sizeof(char));

    //strcpy(argvInitMD[0], IOParam::getExecutablePath());
    strcat(argvInitMD[0], "/home/naziozeno/Documents/projeto-final/AteamSCP/AteamMPI/initMD");

    strcpy(argvInitMD[1], "1");

    //strcpy(argvInitMD[2], IOParam::getExecutablePath());
    strcat(argvInitMD[2], "/home/naziozeno/Documents/projeto-final/AteamSCP/AteamMPI/20_40_20");

    //strcpy(argvInitMD[3], IOParam::getExecutablePath());
    strcat(argvInitMD[3], "/home/naziozeno/Documents/projeto-final/AteamSCP/AteamMPI/teste/");

    argc = argcInitMD;
    argv = argvInitMD;
*/
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm interComSpawn;
  
  char *look = NULL, path[200];
  unsigned long NbServerMD = 0;

  MaxLenDualMem = (int)  ReadAteamParam(2);
  ReducPerc     = (int)  ReadAteamParam(12);
  RandomInitMD  = (char) ReadAteamParam(16);


  if (!(finput = fopen(argv[2],"r")))
   { printf("\n\n* Erro na abertura do arquivo %s. *",argv[2]);
     exit(1);
   }

  ReadSource();
  fclose(finput);
  Reduction(NULL,NULL);
  srand48(time(NULL));

//printf("============================\n");
//  printf("%s\n", argv[0]);  

  if (argc == 4)
    strcpy(path,argv[3]);
  else
    strcpy(path,"./");
  look = argv[2];
  while (look)
    if (look = (char *) strstr(argv[2],"/"))
      argv[2] = (look + 1);
  strcat(path,argv[2]);
  
  char *param = (char *) malloc(200 * sizeof(char));
  strcpy(param, path);

   MPI_Comm_spawn("/home/naziozeno/Documents/projeto-final/AteamSCP/AteamMPI/serverMD", 
        &param, 1, MPI_INFO_NULL, 0,  MPI_COMM_SELF, &interComSpawn, errcodes);

  	char messageBlock[1];
  	MPI_Status status;
  	MPI_Recv(messageBlock, 1, MPI_CHAR, 0, MPI_ANY_TAG, interComSpawn, &status); 

  int  method = INIT_GLOBAL_VARS, position = 0, flagConnect = 1;
  char * buffer, port[MPI_MAX_PORT_NAME];
  MPI_Comm commServerMD;

  flagConnect = MPI_Lookup_name("ServerMD", MPI_INFO_NULL, port);

  if(flagConnect) 
  {
      printf("\n\n Erro: Porta não concebida \n\n");fflush(stdout);
  
  }else{	  
  	  
  	  /* Conecta como serverMD */	
      MPI_Comm_connect(port, MPI_INFO_NULL, 0, MPI_COMM_SELF, &commServerMD);
	  
	  buffer = (char *) malloc(3 * sizeof(int) + sizeof(float) + sizeof(unsigned long));
      
      /* Sequência de empacotamento da primeira mensagem */
	  MPI_Pack(&method, 1, MPI_INT, buffer, 3 * sizeof(int) + sizeof(float) + 
	  	sizeof(unsigned long), &position, commServerMD);
	  
	  /*
	   * Position foi incrementada: passa a referenciar a primeira
	   * posição livre no buffer e assim sucessivamente.   
	   */
	  MPI_Pack(&nb_lin, 1, MPI_INT, buffer, 3 * sizeof(int) + sizeof(float) + 
	  	sizeof(unsigned long), &position, commServerMD);
	  MPI_Pack(&nb_col, 1, MPI_INT, buffer, 3 * sizeof(int) + sizeof(float) + 
	  	sizeof(unsigned long), &position, commServerMD);
	  MPI_Pack(&density, 1, MPI_FLOAT, buffer, 3 * sizeof(int) + sizeof(float) + 
	  	sizeof(unsigned long), &position, commServerMD);
	  MPI_Pack(&NbServerMD, 1, MPI_UNSIGNED_LONG, buffer, 3 * sizeof(int) + 
	  	sizeof(float) + sizeof(unsigned long), &position, commServerMD);	 
	  /*
	   * Envia a mensagem empacotada para o serverMD, fazendo uso do comu-
	   * nicador interComSpawn resultante da chamada a rotina spawn
       */
  	  MPI_Send(buffer, position, MPI_PACKED, 0, 1, commServerMD);
  	  free(buffer);
  }
  
 
   /* A heuristica dual gulosa sera chamada <MaxLenDualMem> vezes para  gerar
	  solucoes que permitam preencher total ou parcialmente a memoria de solu-
	  coes duais. */
   ExecAgInitMD(commServerMD);
   FreeSource();
	
   int i = 0;
   int message = 1224;
   //printf("\n \n Messagen 1224 %d: \n", message);
   
   MPI_Send(&message, 1, MPI_INT, 0, 1, commServerMD);
 

  //return commServerMD;

   MPI_Comm_disconnect(&commServerMD);
   //printf("\n\n* Termino do Agente InitMD *");
   //printf("\n* A memoria de solucoes duais foi inicializada. *\n");
   
   MPI_Finalize();
}
     
/* ------------------------------------------------------------------------- */
void ExecAgInitMD(MPI_Comm communicator)
{
  char     stop        = FALSE,
           sleep_ag    = FALSE,
           new_problem = FALSE;
  int      count       = 0;
  
  DualType DualSol;

  MPI_Datatype	newtype;

  srand48(time(NULL));
  
  DualSol.var_u    = (double *) malloc(max_lin * sizeof(double));
  DualSol.red_cost = (double *) malloc(nb_col * sizeof(double));
  delta_u          = (double *) malloc(nb_lin * sizeof(double));
  I_u              = (int *) malloc((nb_lin+1) * sizeof(int));
  inact            = (int *) malloc(nb_lin * sizeof(int));
  
  //I_u = I_u + nb_lin;
 /*   while ((count++ < MaxLenDualMem) && (!stop)) */
 
 while ((count++ < (MaxLenDualMem / 2)) && (!stop))
 {
     DualSol.nb_cuts   = 0;
     DualSol.proc_time = 0;
     DualSol.cut       = NULL;
     DualGreedy(RandomInitMD,((float) ReducPerc / 100.0),&DualSol);
     SendDualSolutiontoServer(&stop,&sleep_ag,&new_problem,
			                               &DualSol, communicator);
 }
  
 free(DualSol.var_u);
 free(DualSol.red_cost);
 free(delta_u);
 //I_u = I_u - nb_lin;
 free(I_u);
 free(inact);
 
  
  printf("\n\n Termino do exec \n\n");
}
     
/* ------------------------------------------------------------------------- */
/* /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/ */
/* ------------------------------------------------------------------------- */

